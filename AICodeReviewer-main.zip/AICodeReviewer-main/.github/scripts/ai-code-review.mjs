// AI Code Reviewer — Playwright/TypeScript PR reviewer.
// Zero runtime dependencies: uses Node 20+ built-in fetch, the git CLI,
// and the GitHub REST API. The review persona/rules live in Skill-file.md
// at the repository root and are sent as the system prompt.

import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const MARKER = '<!-- ai-code-reviewer -->';
const MAX_DIFF_CHARS = 200_000; // guard against token overflow on huge PRs
const REVIEWABLE = /\.(ts|tsx|js|jsx|mjs|cjs|json|ya?ml)$/i;

function requireEnv(name) {
  const value = process.env[name];
  if (!value) {
    console.error(`Missing required environment variable: ${name}`);
    process.exit(1);
  }
  return value;
}

const GITHUB_EVENT_PATH = requireEnv('GITHUB_EVENT_PATH');
const GITHUB_REPOSITORY = requireEnv('GITHUB_REPOSITORY');
const GITHUB_TOKEN = requireEnv('GITHUB_TOKEN');
const GITHUB_API_URL = process.env.GITHUB_API_URL || 'https://api.github.com';
const GITHUB_EVENT_NAME = process.env.GITHUB_EVENT_NAME || '';

// GitHub Models — reuses the built-in GITHUB_TOKEN, no external provider needed.
// Requires `permissions: models: read` in the workflow.
const MODELS_ENDPOINT =
  process.env.MODELS_ENDPOINT || 'https://models.github.ai/inference/chat/completions';
const MODEL = process.env.MODEL || 'openai/gpt-4o';

const SKILL_FILE = process.env.SKILL_FILE_PATH || 'Skill-file.md';

function git(args) {
  return execFileSync('git', args, { maxBuffer: 1024 * 1024 * 64 }).toString();
}

function readEvent() {
  const event = JSON.parse(readFileSync(GITHUB_EVENT_PATH, 'utf8'));
  const pr = event.pull_request;
  if (!pr) {
    console.error('No pull_request found in event payload. This script must run on pull_request events.');
    process.exit(1);
  }
  return { number: pr.number, baseSha: pr.base.sha, headSha: pr.head.sha };
}

// Resolve PR identity from either the pull_request event payload or, on a
// manual workflow_dispatch run, by fetching the PR by number from the API.
async function resolvePullRequest() {
  if (GITHUB_EVENT_NAME === 'workflow_dispatch') {
    const prNumber = process.env.PR_NUMBER;
    if (!prNumber) {
      console.error('workflow_dispatch run is missing the PR_NUMBER input.');
      process.exit(1);
    }
    const pr = await githubRequest('GET', `/repos/${GITHUB_REPOSITORY}/pulls/${prNumber}`);
    // Ensure the base/head commits are available locally for the diff.
    git(['fetch', 'origin', pr.base.sha, pr.head.sha]);
    return { number: pr.number, baseSha: pr.base.sha, headSha: pr.head.sha };
  }
  return readEvent();
}

function buildDiff(baseSha, headSha) {
  const range = `${baseSha}...${headSha}`;
  const changedFiles = git(['diff', '--name-only', range])
    .split('\n')
    .map((f) => f.trim())
    .filter(Boolean)
    .filter((f) => REVIEWABLE.test(f) && !f.includes('node_modules/'));

  if (changedFiles.length === 0) return { diff: '', files: [] };

  const diff = git(['diff', range, '--', ...changedFiles]);
  return { diff, files: changedFiles };
}

function readSkill() {
  try {
    return readFileSync(SKILL_FILE, 'utf8');
  } catch {
    console.error(`Could not read skill file at "${SKILL_FILE}".`);
    process.exit(1);
  }
}

async function callModel(systemPrompt, userPrompt) {
  const res = await fetch(MODELS_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${GITHUB_TOKEN}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: 0.1,
      max_tokens: 4000,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    console.error(`GitHub Models request failed (${res.status}): ${text}`);
    process.exit(1);
  }

  const data = await res.json();
  const content = data.choices?.[0]?.message?.content?.trim();
  if (!content) {
    console.error('GitHub Models returned an empty response.');
    process.exit(1);
  }
  return content;
}

async function githubRequest(method, path, body) {
  const res = await fetch(`${GITHUB_API_URL}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${GITHUB_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text();
    console.error(`GitHub API ${method} ${path} failed (${res.status}): ${text}`);
    process.exit(1);
  }
  return res.json();
}

// Reuse a single sticky comment per PR instead of spamming a new one each run.
async function upsertComment(prNumber, body) {
  const comments = await githubRequest(
    'GET',
    `/repos/${GITHUB_REPOSITORY}/issues/${prNumber}/comments?per_page=100`,
  );
  const existing = comments.find((c) => typeof c.body === 'string' && c.body.includes(MARKER));

  if (existing) {
    await githubRequest('PATCH', `/repos/${GITHUB_REPOSITORY}/issues/comments/${existing.id}`, { body });
  } else {
    await githubRequest('POST', `/repos/${GITHUB_REPOSITORY}/issues/${prNumber}/comments`, { body });
  }
}

async function main() {
  const { number, baseSha, headSha } = await resolvePullRequest();
  const { diff, files } = buildDiff(baseSha, headSha);

  if (!diff) {
    await upsertComment(number, `${MARKER}\n### AI Code Reviewer\n\nNo reviewable Playwright/TypeScript changes found in this PR.`);
    console.log('No reviewable changes. Exiting.');
    return;
  }

  let payloadDiff = diff;
  let truncationNote = '';
  if (payloadDiff.length > MAX_DIFF_CHARS) {
    payloadDiff = payloadDiff.slice(0, MAX_DIFF_CHARS);
    truncationNote = `\n\n> NOTE: The diff was truncated to ${MAX_DIFF_CHARS} characters. Review the remaining changes manually.`;
  }

  const systemPrompt = readSkill();
  const userPrompt = [
    'Review the following Pull Request diff using your skill rules and output format.',
    'Only review the changed lines, but use the surrounding context shown in the diff.',
    '',
    `Changed files (${files.length}):`,
    ...files.map((f) => `- ${f}`),
    '',
    'Unified diff:',
    '```diff',
    payloadDiff,
    '```',
  ].join('\n');

  console.log(`Reviewing PR #${number} — ${files.length} file(s), ${payloadDiff.length} diff chars.`);
  const review = await callModel(systemPrompt, userPrompt);

  const body = `${MARKER}\n${review}${truncationNote}\n\n---\n<sub>Generated by the AI Code Reviewer (GitHub Models · \`${MODEL}\`).</sub>`;
  await upsertComment(number, body);
  console.log('Review posted.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
